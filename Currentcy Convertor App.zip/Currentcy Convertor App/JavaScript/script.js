const dropList = document.querySelectorAll(".drop-list select"),
    fromCurrency = document.getElementById("from-select"),
    toCurrency = document.getElementById("to-select"),
    getButton = document.querySelector("form button");

// Populate dropdown with currencies and flags
for (let select of dropList) {
    for (let currency_code in country_code) {
        let selected = "";
        if (select.id === "from-select" && currency_code === "USD") selected = "selected";
        if (select.id === "to-select" && currency_code === "NPR") selected = "selected";

        let optionTag = `<option value="${currency_code}" ${selected}>${currency_code}</option>`;
        select.insertAdjacentHTML("beforeend", optionTag);
    }
    select.addEventListener("change", (e) => {
        loadFlag(e.target);
    });
}

// Function to update flag when currency is changed
function loadFlag(element) {
    let currencyCode = element.value;
    let imgTag = element.parentElement.querySelector("img");
    if (imgTag) {
        imgTag.src = `https://flagsapi.com/${country_code[currencyCode]}/flat/64.png`;
    }
}



// Fetch exchange rate on button click
window.addEventListener("load", () => {
    getExchangeRate();
});

getButton.addEventListener("click", (e) => {
    e.preventDefault();
    getExchangeRate();
});

// Swap currency values on clicking the exchange icon
document.querySelector(".icon").addEventListener("click", () => {
    let tempCode = fromCurrency.value;
    fromCurrency.value = toCurrency.value;
    toCurrency.value = tempCode;
    loadFlag(fromCurrency);
    loadFlag(toCurrency);
    getExchangeRate();
});

// Function to fetch exchange rates
function getExchangeRate() {
    const amountInput = document.querySelector(".amount input");
    const exchangeRateTxt = document.querySelector(".exchange-rate");
    let amountVal = amountInput.value;

    if (amountVal === "" || amountVal === "0") {
        amountInput.value = "1";
        amountVal = 1;
    }

    exchangeRateTxt.innerText = "Getting Exchange Rate...";

    let url = `https://v6.exchangerate-api.com/v6/d6bcd06ccd28a6712a85244e/latest/${fromCurrency.value}`;
    
    fetch(url)
    .then((response) => response.json())
    .then((result) => {
        if (result.conversion_rates && result.conversion_rates[toCurrency.value]) {
            let exchangeRate = result.conversion_rates[toCurrency.value];
            let totalExchangeRate = (amountVal * exchangeRate).toFixed(2);
            exchangeRateTxt.innerText = `${amountVal} ${fromCurrency.value} = ${totalExchangeRate} ${toCurrency.value}`;
        } else {
            exchangeRateTxt.innerText = "Exchange rate not available.";
        }
    })
    .catch(() => {
        exchangeRateTxt.innerText = "Something went wrong.";
    });
}

window.addEventListener("load", () => {
    fromCurrency.value = "USD";  // Set USD as default for "From"
    toCurrency.value = "INR";    // Set INR as default for "To"
    loadFlag(fromCurrency);
    loadFlag(toCurrency);
    getExchangeRate();
});


